package com.aglistech.unittesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnittestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnittestingApplication.class, args);
	}

}
